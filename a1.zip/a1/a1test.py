"""
Test script for module a1

When run as a script, this module invokes several procedures that 
test the various functions in the module a1.

Author: Mr. Park
"""
import a1

def testA():
    pass

testA()
print('Module a1 passed all tests')